import sys
import os
import glob
import pandas as pd
from tabulate import tabulate
from collections import defaultdict

def parse_time(time_str):
    """Convert time string formatted as HH:MM:SS.SS to total seconds."""
    if ':' not in time_str:
        return float(time_str)
    hrs, mins, secs = 0, 0, 0
    parts = time_str.split(':')
    if len(parts) == 3:
        hrs = int(parts[0])
        mins = int(parts[1])
        secs = float(parts[2])
    elif len(parts) == 2:
        mins = int(parts[0])
        secs = float(parts[1])
    total_seconds = hrs * 3600 + mins * 60 + secs
    return total_seconds

def parse_performance(line):
    """Parse lines with performance metrics."""
    metrics = {}
    parts = line.strip('[]').split(',')
    for part in parts:
        key, value = part.split(':')
        metrics[key.strip()] = float(value.strip())
    return metrics

def extract_metrics(file_path):
    metrics = {}
    with open(file_path, 'r') as file:
        lines = file.readlines()
    capture = False
    for line in lines:
        line = line.strip()
        if line.startswith("[INFO"):
            continue;
        if line.startswith('***** predict metrics *****'):
            capture = True  # Start capturing metrics
        elif line.startswith('*****') and capture:
            capture = False  # Stop capturing metrics

        if capture or line.startswith(('[predictions]', '[groundtruth]', '[Model performance]', '[Human performance]')):
            if '=' in line:
                key, value = line.split('=', 1)  # Split only on the first '=' found
                key = key.strip()
                value = value.strip()
                try:
                    metrics[key] = float(value)
                except ValueError:
                    metrics[key] = parse_time(value)  # Attempt to parse time
            elif ':' in line and '[' in line and ']' in line:
                key = line.split(']', 1)[0] + ']'  # Split only on the first ']'
                content = line.split(']', 1)[1].strip()
                if ',' in content:  # Multiple metrics on the same line
                    measurements = content.split(',')
                    for measure in measurements:
                        if ' ' in measure:
                            k, v = measure.strip().split(' ', 1)
                            metrics[key + ' ' + k] = float(v)
                else:
                    if '=' in content:  # Ensure there's an '=' to split on
                        _, val = content.split('=')
                        metrics[key] = int(val.strip())
    return metrics

def discover_models(base_dir):
    """Discover models by finding directories under each base directory."""
    return [name for name in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, name))]

def truncate_header(header, max_length=20):
    """Truncate header names to a maximum length with an ellipsis to indicate truncation."""
    if len(header) > max_length:
        return header[:max_length-3] + '...'
    return header

def bold_max_values(s):
    """Apply bold and red ANSI escape codes to the maximum value in the column."""
    is_max = s == s.max()
    return ['\033[1m\033[31m' + f"{x:.4f}" + '\033[0m' if max else f"{x:.4f}" for x, max in zip(s, is_max)]

def main(base_patterns):
    all_metrics = defaultdict(lambda: defaultdict(list))
    
    # Find all matching base directories
    base_directories = []
    for pattern in base_patterns:
        base_directories.extend(glob.glob(pattern))
    
    # Iterate over each found base directory and discover models
    for base_dir in base_directories:
        models = discover_models(base_dir)
        for model in models:
            model_dir = os.path.join(base_dir, model)
            log_file = os.path.join(model_dir, 'evaluation.log')
            if os.path.isfile(log_file):
                metrics = extract_metrics(log_file)
                for key, value in metrics.items():
                    all_metrics[model][key].append(value)
    
    # Prepare data for DataFrame
    data = []
    for model, metrics in all_metrics.items():
        entry = {'Model': model}
        for metric, values in metrics.items():
            if values:
                average_value = sum(values) / len(values)
                entry[f"{metric}"] = average_value
        data.append(entry)

    # Create DataFrame
    df = pd.DataFrame(data)
    df.set_index('Model', inplace=True)
    df.sort_index(inplace=True)

    # Filter to include only F1 and other desired scores
    df = df.filter(regex='accuracy|f1|Precision|Recall|F1|unanswerable questions')

    # Remove "predict_" from column headers
    df.columns = [col.replace('predict_', '') for col in df.columns]

    # Remove "predict_" from column headers
    df.columns = [col.replace('[predictions] unanswerable questions', 'ua-pred') for col in df.columns]

    # Remove "predict_" from column headers
    df.columns = [col.replace('[groundtruth] unanswerable questions', 'ua-true') for col in df.columns]

    # Remove "predict_" from column headers
    df.columns = [col.replace('[Model performance] Precision:', 'Model-Precision') for col in df.columns]

    # Remove "predict_" from column headers
    df.columns = [col.replace('[Model performance] Recall:', 'Model-Recall') for col in df.columns]

    # Remove "predict_" from column headers
    df.columns = [col.replace('[Model performance] F1:', 'Model-F1') for col in df.columns]

    # Remove "predict_" from column headers
    df.columns = [col.replace('[Human performance] Precision:', 'Human-Precision') for col in df.columns]

    # Remove "predict_" from column headers
    df.columns = [col.replace('[Human performance] Recall:', 'Human-Recall') for col in df.columns]

    # Remove "predict_" from column headers
    df.columns = [col.replace('[Human performance] F1:', 'Human-F1') for col in df.columns]

    # Truncate column headers to 20 chars
    df.columns = [truncate_header(col) for col in df.columns]

    # Apply Bold
    df = df.apply(bold_max_values)

    # Print the DataFrame in a nice table format
    print(tabulate(df, headers='keys', tablefmt='psql', showindex=True, floatfmt=".4f"))

if __name__ == "__main__":
    main(sys.argv[1:])

